# Architecture

## Overview

ReclaimAI is deliberately a single-page, no-backend app for this submission. Every
"agent" behavior — scoring, decisioning, workflow execution, stopping rules,
audit logging — is real, running code; only the **inputs** (the transaction batch)
and the **channel outcomes** (did the SMS actually convert) are synthetic/simulated,
because a buildathon judge cannot be handed a live Razorpay account or a live
customer's inbox. Everything is structured so those two things are the only parts
that change in a production build.

```
┌─────────────┐    ┌──────────────┐    ┌──────────────┐    ┌─────────────┐
│  data.js     │ →  │ scoring.js   │ →  │ engine.js    │ →  │  ui.js       │
│  batch of    │    │ recoverability│   │ escalation + │    │ KPIs, charts,│
│  RecoveryEvents│  │ score + policy│   │ stopping rules│   │ table, log   │
└─────────────┘    └──────────────┘    │ audit trail  │    └─────────────┘
                                        └──────────────┘
                          ↑ swap point for a          ↑ swap point for a real
                            trained model or LLM         Razorpay Payments/Invoices
                                                          feed + messaging provider
```

## The `RecoveryEvent` shape

Everything downstream of `data.js` depends only on this shape, so replacing the
generator with a real data source is the entire integration:

```js
{
  id, category,             // 'failed_payment' | 'abandoned_checkout' | 'overdue_invoice'
  customerName, company,
  amount, currency,
  eventDate, daysSinceEvent,
  paymentMethod, failureReason, failureLabel, failureTransient,
  tenureMonths, priorSuccessfulPayments, isRepeatCustomer, doNotContact,
  // populated by scoring.js / engine.js at run time:
  score, scoreFactors, policy,
  status, escalationStage, contactAttempts,
  recoveredAmount, recoveredOnDay, auditLog,
}
```

## Scoring model (`js/scoring.js`)

A weighted-factor model, not a trained classifier — chosen on purpose. The AI
Revenue Recovery bar explicitly asks for judgment a human can audit; a bare score
number is not enough, so `scoreEvent()` returns both the score **and** the ordered
list of named factors that produced it (`{ label, delta }`), which is what powers
the "why this score" breakdown on every row in the table.

Factors: recency decay, category, failure-reason (transient failures like a bank
timeout score *up*, since a bare retry is likely to succeed; hard declines like an
expired card score down, since they need a new instrument), customer tenure,
prior payment history, repeat-customer flag, amount band. A `doNotContact` flag
short-circuits the score to 0 and suppresses the event before any other logic runs.

**Swap-in point:** replace the factor weights with a trained propensity model, or
call an LLM to re-rank borderline (score 35–55) cases — as long as `scoreEvent()`
still returns `{ score, factors }`, nothing in `engine.js` or `ui.js` changes.
An LLM is *not* wired in for this submission because the artifact-hosted demo runs
sandboxed with outbound network calls blocked, and because an explainable baseline
was the safer choice against the "appropriate AI implementation, not overuse"
judging note. The natural place for a real call is inside `decidePolicy()`, to turn
`{channel, offer, urgency}` into an actually-personalized message — the decision
*what* to do would stay rule-based and auditable; only the *wording* would be
generated.

## Workflow engine (`js/engine.js`)

Each category has a fixed escalation plan — a small, readable table
(`CATEGORY_PLANS`), not a learned policy — because a compliance reviewer needs to
be able to read the whole playbook in one sitting. `runSimulation()` steps every
event through its plan, checking stopping rules before every action, and writes one
audit-log entry per action taken *or withheld*.

**Recovery playbooks:**

- **Failed payment** — Day 0 automated retry → Day 2 SMS nudge → Day 5 offer email
  (or a priority call for low-recoverability cases) → Day 9 final notice.
- **Abandoned checkout** — Day 0 reminder email → Day 1 SMS nudge → Day 3 offer
  email → Day 7 final notice.
- **Overdue receivable** — Day 0 reminder email → Day 3 SMS nudge → Day 7
  payment-plan offer → Day 10 handoff to a human collections agent.

**Stopping rules (enforced in code, not just documented):**

1. **Contact/retry cap** — 3 attempts (4 for invoices). A hard-declined card is
   auto-retried at most once before the channel switches to messaging, so the agent
   never repeatedly hits a card network with a doomed retry.
2. **Do-not-contact** — checked once, before any action is generated for that event.
3. **Quiet hours** — a scheduled send that would land 9pm–9am IST is deferred to the
   next window, and that deferral is itself a logged, visible action.
4. **Recovery-window timeout** — 10–21 days depending on category. An unresolved
   case is closed and (conceptually) handed to standard collections rather than
   pursued indefinitely.

A fifth implicit rule: **recovery stops all further action** — the instant an event
is marked `recovered`, its loop exits and no further contact is scheduled.

**Swap-in point:** replace the Bernoulli outcome draw in the main loop
(`rng.float() < p`) with a real webhook callback from a payment gateway or messaging
provider, and replace the synthetic day-stepper with a real cron/queue. The plan
table, the stopping-rule checks, and the audit logging do not need to change.

## Audit trail

Every `log()` call in `engine.js` appends an immutable entry
(`{ tick, day, eventId, type, message, rule? }`) to both the event's own `auditLog`
and a flat, chronologically-sorted `timeline` for the whole batch. The UI's live
"agent activity" panel is a direct playback of that timeline; the per-row detail
drawer is a filter of it by `eventId`. Nothing is synthesized for display — the log
*is* the source of truth the KPIs are computed from.

## Why no backend

For a same-day buildathon submission, a backend buys nothing a judge can verify and
costs setup time that isn't available. Every "agent" behavior specified by the track
— scoring, escalation, stopping rules, audit trail, measured recovery — is real
logic running in the browser, seeded and reproducible. The two things a backend
*would* add — a live Razorpay feed and real message delivery — are exactly the two
places this codebase is structured to swap in without touching anything else
(see the two "swap-in point" notes above).
