# 5-minute pitch video — outline

Razorpay's application asks for a ~5 minute pitch video showing a **working
product**, plus an explanation of technical failures you hit and how you solved
them. Use this as a scaffold, not a script to read word-for-word — say it in your
own voice. Bracketed notes are things only you can fill in.

Record your screen (index.html open, sound on) with a simple tool — OBS, or even
the built-in screen recorder on your laptop. You do not need to be on camera; a
clear voiceover over the app is enough.

---

### 0:00–0:30 — The problem (state it, don't over-explain)

> "Every SaaS or D2C business loses revenue it already earned — a card that fails
> at checkout, a cart abandoned one step from payment, an invoice nobody chased.
> Most of that money is recoverable, but only if someone follows up — consistently,
> compliantly, and without harassing the customer. That's the AI Revenue Recovery
> track: build an agent that does that follow-up, and prove it worked."

### 0:30–1:15 — What you built, in one sentence, then show it

> "This is ReclaimAI. It scores every failed payment, abandoned checkout and
> overdue invoice for recoverability, runs each one through a bounded recovery
> playbook, and reports exactly how much it recovered — with every action logged."

Hit **Run recovery batch** live. Let the KPI row count up and the audit log stream.
Point at the numbers as they land: at-risk revenue, recovered, recovery rate.

### 1:15–2:30 — Walk the mechanism, not just the UI

- Still on **Overview**: point at the "What the agent adds, over doing nothing
  smart" strip — "this batch, run two ways: one flat reminder to everyone, versus
  ReclaimAI's scored, staged approach. [Say your actual multiplier out loud —
  e.g. '1.5x the recovery, same batch.']" This is your ROI line — say it plainly,
  it's the number a judge remembers.
- Switch to **Portfolio**. Click a row in the leaderboard or table — show the score
  breakdown in the drawer: "this is not a black box, every point is a named
  factor," then point at its mini audit timeline.
- Switch to **Playbook & Controls**. Point at the playbook — "each category has a
  fixed escalation plan: [name the steps for one category]." Then point at
  Guardrails — the part most AI-collections demos skip. "The agent stops. Contact
  caps, do-not-contact, quiet hours, a hard timeout that hands unresolved cases to
  a human. [escalated count] + [guardrail-closed count] out of [n] events were
  closed *without* recovering — the point is that it's bounded, not relentless."
- Optional strong beat if you have time: drag the **contact-cap** or **offer
  strength** slider up and hit "Apply & re-run" live. Recovery rate visibly moves.
  "It's tunable within bounds — nothing here lets it remove a guardrail outright."
- Switch to **Insights** — the executive summary is computed from the actual run,
  not written by me: "[read one bullet verbatim, it'll be different on your run]."
  Point at the channel chart and the recovery calendar for 5 seconds each, no need
  to over-explain them.

### 2:30–3:15 — Architecture, briefly

> "It's a single-page app — no backend for this build. `data.js` generates a
> reproducible synthetic batch standing in for a real Razorpay Payments and
> Invoices feed. `scoring.js` is the recoverability model — I kept it as a
> transparent weighted model instead of a black-box classifier, because for
> anything touching a customer's money, explainable beats clever. `engine.js` is
> the workflow — the escalation plans and the four stopping rules — and it writes
> an audit entry for every action, taken or withheld. The only two places a
> production version changes are: real data in, real webhook callbacks for
> outcomes instead of the simulated draw."

*(See `docs/ARCHITECTURE.md` if you want the full breakdown while you write this
part — it names the exact swap-in points.)*

### 3:15–4:15 — What broke, and what you did about it

This is the part Razorpay explicitly asks for. Some genuine trade-offs made while
building this you can speak to honestly:

- **Chose synthetic, seeded data over live Razorpay integration.** A single-day
  build with a real payments account means auth, sandbox setup, and PII handling —
  none of which is the actual thing being judged. A seeded generator gets a
  reproducible, inspectable batch in seconds and keeps the whole demo
  self-contained. `[Say this in your own words, plus anything else you personally
  ran into — e.g. "I originally tried X and switched to Y because..." — this
  section is more convincing in your own voice than read from a card.]`
- **Chose a rule-based scoring model over calling an LLM.** Explainability was an
  explicit judging bar, and the artifact-hosted version of this demo is sandboxed
  against outbound network calls anyway — so an auditable weighted model that
  degrades to nothing if a network call fails felt like the more honest choice
  than dressing up a prompt as "AI". `[Add your own reasoning if you'd say it
  differently.]`
- `[If you hit and fixed anything else — a layout bug, a data bug you caught in
  the audit log while testing, a number that looked wrong until you traced it back
  to the scoring model — say it here. Judges are explicitly told to weigh "how you
  deal with things when they break," so a real, specific bug you caught beats a
  vague "everything went smoothly."]`

### 4:15–5:00 — Close

> "This maps directly to the track's bar: measured money recovered across a batch,
> compliant escalation, stopping rules, and a full audit trail — [restate your
> actual headline numbers from this run]. Repo's linked below, everything runs
> client-side, no setup required to try it yourself."

---

## Numbers to have ready before you record

Run the batch once, screenshot or note down: at-risk revenue, recovered, recovery
rate, escalated-to-human count, closed-by-guardrail count. Use the *same* run's
numbers throughout the video so they're consistent — re-running with a new seed
mid-recording will change them.
