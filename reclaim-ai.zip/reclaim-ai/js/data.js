/**
 * data.js — synthetic revenue-loss batch generator
 * -------------------------------------------------
 * ReclaimAI never touches a real payment gateway. For the buildathon demo it
 * generates a reproducible batch of synthetic revenue-loss events that stand
 * in for a mid-size Indian SaaS/D2C merchant's ledger: failed payments,
 * abandoned checkouts and overdue receivables. Swap this module for a real
 * Razorpay Payments/Invoices API poller in production — nothing downstream
 * (scoring.js, engine.js) needs to change, because both only depend on the
 * RecoveryEvent shape defined below.
 */
(function (global) {
  'use strict';

  // ---- seeded PRNG (mulberry32) so every "Run batch" is reproducible ----
  function mulberry32(seed) {
    return function () {
      seed |= 0; seed = (seed + 0x6d2b79f5) | 0;
      let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  function makeRng(seed) {
    const rand = mulberry32(seed);
    return {
      float: (a = 0, b = 1) => a + rand() * (b - a),
      int: (a, b) => Math.floor(a + rand() * (b - a + 1)),
      pick: (arr) => arr[Math.floor(rand() * arr.length)],
      weighted(pairs) {
        const total = pairs.reduce((s, p) => s + p[1], 0);
        let r = rand() * total;
        for (const [val, w] of pairs) { if ((r -= w) <= 0) return val; }
        return pairs[pairs.length - 1][0];
      },
      bool: (p = 0.5) => rand() < p,
    };
  }

  const FIRST_NAMES = ['Aarav','Vivaan','Aditya','Diya','Ananya','Ishaan','Kabir','Meera','Riya','Sai',
    'Neha','Rohan','Priya','Karan','Sanya','Arjun','Tara','Yash','Zoya','Devika',
    'Nikhil','Pooja','Rahul','Simran','Varun','Aisha','Manav','Kiara','Rudra','Anika'];
  const LAST_NAMES = ['Sharma','Verma','Iyer','Nair','Gupta','Reddy','Khan','Chatterjee','Malhotra','Bose',
    'Kapoor','Menon','Joshi','Rao','Bansal','Pillai','Chawla','Desai','Agarwal','Mehta'];
  const COMPANIES = ['Bloomrun Retail','Nimbus Fitness','CraftLoop Studio','Payflo Analytics','Verdant Foods',
    'Northgate Logistics','Kestrel SaaS','Orbit Learning','Halcyon Health','Frameworks Design',
    'Aster Home Decor','Loomweave Textiles','Quicksand Media','Bramble & Co','Solstice Travel'];

  const FAILURE_REASONS = [
    { key: 'insufficient_funds', label: 'Insufficient funds', transient: false, weight: 30 },
    { key: 'card_declined',      label: 'Card declined',      transient: false, weight: 22 },
    { key: 'bank_timeout',       label: 'Bank/issuer timeout', transient: true,  weight: 16 },
    { key: 'network_error',      label: 'Network/gateway error', transient: true, weight: 12 },
    { key: '3ds_failure',        label: '3-D Secure auth failed', transient: true,  weight: 12 },
    { key: 'expired_card',       label: 'Card expired',       transient: false, weight: 8 },
  ];
  const PAYMENT_METHODS = ['UPI', 'Card', 'Netbanking', 'Wallet'];

  const CATEGORY_MIX = [
    ['failed_payment', 45],
    ['abandoned_checkout', 35],
    ['overdue_invoice', 20],
  ];

  const CATEGORY_META = {
    failed_payment:     { label: 'Failed payment',     short: 'Payment' },
    abandoned_checkout: { label: 'Abandoned checkout',  short: 'Checkout' },
    overdue_invoice:    { label: 'Overdue receivable',  short: 'Invoice' },
  };

  /** Generate one synthetic revenue-loss event. */
  function makeEvent(rng, index, today) {
    const category = rng.weighted(CATEGORY_MIX);
    const person = `${rng.pick(FIRST_NAMES)} ${rng.pick(LAST_NAMES)}`;
    const isB2B = category === 'overdue_invoice' || rng.bool(0.3);

    // Amount distributions differ by category (INR).
    let amount;
    if (category === 'overdue_invoice') amount = Math.round(rng.float(4000, 180000) / 100) * 100;
    else if (category === 'failed_payment') amount = Math.round(rng.float(299, 24999) / 10) * 10;
    else amount = Math.round(rng.float(499, 15999) / 10) * 10;

    const daysSinceEvent = category === 'overdue_invoice'
      ? rng.int(1, 45)
      : rng.int(0, 21);

    const tenureMonths = rng.bool(0.55) ? rng.int(0, 3) : rng.int(4, 36);
    const priorSuccessfulPayments = tenureMonths === 0 ? 0 : rng.int(0, Math.min(24, tenureMonths));
    const isRepeatCustomer = priorSuccessfulPayments >= 3;
    const doNotContact = rng.bool(0.06);

    const failureReason = category === 'failed_payment' ? rng.pick(FAILURE_REASONS) : null;

    return {
      id: `RE-${String(1000 + index)}`,
      category,
      customerName: person,
      company: isB2B ? rng.pick(COMPANIES) : null,
      amount,
      currency: 'INR',
      eventDate: new Date(today.getTime() - daysSinceEvent * 86400000).toISOString().slice(0, 10),
      daysSinceEvent,
      paymentMethod: rng.pick(PAYMENT_METHODS),
      failureReason: failureReason ? failureReason.key : null,
      failureLabel: failureReason ? failureReason.label : null,
      failureTransient: failureReason ? failureReason.transient : null,
      tenureMonths,
      priorSuccessfulPayments,
      isRepeatCustomer,
      doNotContact,
      // mutable state, populated by engine.js at simulation time
      status: 'new',
      escalationStage: 0,
      contactAttempts: 0,
      recoveredAmount: 0,
      recoveredOnDay: null,
      auditLog: [],
    };
  }

  /**
   * Generate a full synthetic batch.
   * @param {number} seed  RNG seed — same seed always produces the same batch.
   * @param {number} size  number of events.
   */
  function generateBatch(seed, size) {
    const rng = makeRng(seed >>> 0);
    const today = new Date();
    const events = [];
    for (let i = 0; i < size; i++) events.push(makeEvent(rng, i, today));
    return events;
  }

  global.ReclaimData = { generateBatch, CATEGORY_META, FAILURE_REASONS, makeRng };
})(typeof window !== 'undefined' ? window : globalThis);
