/**
 * charts.js — three hand-built inline-SVG charts, drawn against the theme
 * tokens so they hold in both light and dark. No charting library: at this
 * size, plain SVG gives full control over mark specs (rounded bar ends,
 * 2px surface gaps between stacked segments, a shared hover/tooltip layer)
 * that a generic library would fight.
 */
(function (global) {
  'use strict';

  const SVGNS = 'http://www.w3.org/2000/svg';
  function el(tag, attrs, parent) {
    const n = document.createElementNS(SVGNS, tag);
    for (const k in attrs) n.setAttribute(k, attrs[k]);
    if (parent) parent.appendChild(n);
    return n;
  }
  function cssVar(name) {
    return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  }
  function mix(hexA, hexB, t) {
    const a = hexA.replace('#', ''), b = hexB.replace('#', '');
    const pa = [0, 2, 4].map((i) => parseInt(a.slice(i, i + 2), 16));
    const pb = [0, 2, 4].map((i) => parseInt(b.slice(i, i + 2), 16));
    const c = pa.map((v, i) => Math.round(v + (pb[i] - v) * t));
    return `rgb(${c[0]},${c[1]},${c[2]})`;
  }
  function fmtINR(n) {
    if (Math.abs(n) >= 100000) return '₹' + (n / 100000).toFixed(2) + 'L';
    return '₹' + Math.round(n).toLocaleString('en-IN');
  }

  // shared tooltip element, created once, reused by every chart on the page
  let tipEl = null;
  function tooltip() {
    if (tipEl) return tipEl;
    tipEl = document.createElement('div');
    tipEl.className = 'chart-tooltip';
    document.body.appendChild(tipEl);
    return tipEl;
  }
  function showTip(evt, html) {
    const t = tooltip();
    t.innerHTML = html;
    t.classList.add('show');
    moveTip(evt);
  }
  function moveTip(evt) {
    const t = tooltip();
    const pad = 14;
    let x = evt.clientX + pad, y = evt.clientY + pad;
    const rect = t.getBoundingClientRect();
    if (x + rect.width > window.innerWidth - 8) x = evt.clientX - rect.width - pad;
    if (y + rect.height > window.innerHeight - 8) y = evt.clientY - rect.height - pad;
    t.style.left = x + 'px'; t.style.top = y + 'px';
  }
  function hideTip() { if (tipEl) tipEl.classList.remove('show'); }

  /** Horizontal stacked bar: outcome mix per category. */
  function buildStackedBarChart(container, rows, segments) {
    container.innerHTML = '';
    const width = 560, rowH = 46, gap = 14, left = 132, right = 54;
    const height = rows.length * (rowH + gap) - gap + 8;
    const svg = el('svg', { class: 'chart-svg', viewBox: `0 0 ${width} ${height}`, role: 'img', 'aria-label': 'Recovery outcome by category' }, container);
    const plotW = width - left - right;
    const max = Math.max(1, ...rows.map((r) => r.total));

    rows.forEach((row, i) => {
      const y = i * (rowH + gap);
      el('text', { x: 0, y: y + rowH / 2 - 6, class: 'value-label' }, svg).textContent = row.label;
      el('text', { x: 0, y: y + rowH / 2 + 10, fill: cssVar('--ink-muted') }, svg).textContent = `${row.total} events`;

      let x = left;
      const barW = plotW;
      segments.forEach((seg) => {
        const count = row.counts[seg.key] || 0;
        if (!count) return;
        const w = Math.max(0, (count / max) * barW - 2);
        const isFirst = x === left;
        const rect = el('rect', {
          x, y: y + 6, width: Math.max(w, 2), height: rowH - 12,
          rx: 4, fill: seg.color,
        }, svg);
        rect.style.cursor = 'pointer';
        rect.addEventListener('mousemove', (e) => showTip(e,
          `<div class="t-title">${row.label} — ${seg.label}</div>${count} event${count === 1 ? '' : 's'} · ${fmtINR(row.amounts[seg.key] || 0)}`));
        rect.addEventListener('mouseleave', hideTip);
        x += w + 2;
      });
      // baseline
      el('line', { x1: left, x2: left + barW, y1: y + rowH + 3, y2: y + rowH + 3, stroke: cssVar('--hairline'), 'stroke-width': 1 }, svg);
    });

    const legend = document.createElement('div');
    legend.className = 'legend';
    legend.innerHTML = segments.map((s) => `<span class="legend-item"><span class="legend-swatch" style="background:${s.color}"></span>${s.label}</span>`).join('');
    container.appendChild(legend);
  }

  /** Escalation funnel: how many events reached each contact stage. */
  function buildFunnelChart(container, stages) {
    container.innerHTML = '';
    const width = 560, rowH = 34, gap = 12, left = 168, right = 60;
    const height = stages.length * (rowH + gap) - gap + 6;
    const svg = el('svg', { class: 'chart-svg', viewBox: `0 0 ${width} ${height}`, role: 'img', 'aria-label': 'Escalation funnel by stage' }, container);
    const plotW = width - left - right;
    const max = Math.max(1, stages[0].count);
    const brand = cssVar('--brand') || '#1baf7a';
    const surface = cssVar('--surface') || '#ffffff';

    stages.forEach((s, i) => {
      const y = i * (rowH + gap);
      const w = Math.max(6, (s.count / max) * plotW);
      const shade = mix(brand, surface, i * 0.22);
      el('text', { x: 0, y: y + rowH / 2 + 4, class: 'value-label' }, svg).textContent = s.label;
      const rect = el('rect', { x: left, y, width: w, height: rowH, rx: 4, fill: shade }, svg);
      rect.style.cursor = 'pointer';
      rect.addEventListener('mousemove', (e) => showTip(e, `<div class="t-title">${s.label}</div>${s.count} events reached this step · ${Math.round((s.count / stages[0].count) * 100)}% of stage 0`));
      rect.addEventListener('mouseleave', hideTip);
      el('text', { x: left + w + 8, y: y + rowH / 2 + 4, fill: cssVar('--ink-2'), 'font-weight': 600 }, svg).textContent = s.count;
    });
  }

  /** Cumulative ₹ recovered over the simulated recovery window. */
  function buildAreaChart(container, points) {
    container.innerHTML = '';
    const width = 900, height = 220, m = { l: 56, r: 16, t: 16, b: 26 };
    const plotW = width - m.l - m.r, plotH = height - m.t - m.b;
    const svg = el('svg', { class: 'chart-svg', viewBox: `0 0 ${width} ${height}`, role: 'img', 'aria-label': 'Cumulative revenue recovered by simulated day' }, container);
    const maxX = Math.max(1, points[points.length - 1].day);
    const maxY = Math.max(1, ...points.map((p) => p.value)) * 1.12;
    const xAt = (d) => m.l + (d / maxX) * plotW;
    const yAt = (v) => m.t + plotH - (v / maxY) * plotH;

    const brand = cssVar('--brand') || '#1baf7a';
    const gridId = 'rg' + Math.random().toString(36).slice(2, 8);
    const defs = el('defs', {}, svg);
    const grad = el('linearGradient', { id: gridId, x1: 0, y1: 0, x2: 0, y2: 1 }, defs);
    el('stop', { offset: '0%', 'stop-color': brand, 'stop-opacity': 0.28 }, grad);
    el('stop', { offset: '100%', 'stop-color': brand, 'stop-opacity': 0.02 }, grad);

    // gridlines (4 bands) + y labels
    for (let i = 0; i <= 4; i++) {
      const v = (maxY / 4) * i;
      const y = yAt(v);
      el('line', { x1: m.l, x2: width - m.r, y1: y, y2: y, stroke: cssVar('--hairline'), 'stroke-width': 1 }, svg);
      el('text', { x: 0, y: y + 3, fill: cssVar('--ink-muted') }, svg).textContent = fmtINR(v);
    }
    // x labels
    const xTickEvery = Math.max(1, Math.round(maxX / 7));
    for (let d = 0; d <= maxX; d += xTickEvery) {
      el('text', { x: xAt(d), y: height - 4, 'text-anchor': 'middle', fill: cssVar('--ink-muted') }, svg).textContent = 'D' + d;
    }

    const linePts = points.map((p) => `${xAt(p.day)},${yAt(p.value)}`).join(' ');
    const areaPts = `${m.l},${yAt(0)} ${linePts} ${xAt(points[points.length - 1].day)},${yAt(0)}`;
    el('polygon', { points: areaPts, fill: `url(#${gridId})` }, svg);
    el('polyline', { points: linePts, fill: 'none', stroke: brand, 'stroke-width': 2.5, 'stroke-linejoin': 'round', 'stroke-linecap': 'round' }, svg);

    const last = points[points.length - 1];
    el('circle', { cx: xAt(last.day), cy: yAt(last.value), r: 4.5, fill: brand, stroke: cssVar('--surface'), 'stroke-width': 2 }, svg);

    // hover crosshair + tooltip via an invisible capture rect
    const cross = el('line', { x1: 0, x2: 0, y1: m.t, y2: m.t + plotH, stroke: cssVar('--ink-muted'), 'stroke-width': 1, opacity: 0 }, svg);
    const dot = el('circle', { r: 4, fill: brand, opacity: 0 }, svg);
    const capture = el('rect', { x: m.l, y: m.t, width: plotW, height: plotH, fill: 'transparent' }, svg);
    capture.style.cursor = 'crosshair';
    capture.addEventListener('mousemove', (e) => {
      const rectBox = svg.getBoundingClientRect();
      const scale = width / rectBox.width;
      const mx = (e.clientX - rectBox.left) * scale;
      const day = Math.round(((mx - m.l) / plotW) * maxX);
      const clamped = Math.max(0, Math.min(maxX, day));
      let nearest = points[0];
      for (const p of points) if (p.day <= clamped) nearest = p; else break;
      cross.setAttribute('x1', xAt(nearest.day)); cross.setAttribute('x2', xAt(nearest.day)); cross.setAttribute('opacity', 1);
      dot.setAttribute('cx', xAt(nearest.day)); dot.setAttribute('cy', yAt(nearest.value)); dot.setAttribute('opacity', 1);
      showTip(e, `<div class="t-title">Day ${nearest.day}</div>${fmtINR(nearest.value)} recovered cumulatively`);
    });
    capture.addEventListener('mouseleave', () => { cross.setAttribute('opacity', 0); dot.setAttribute('opacity', 0); hideTip(); });
  }

  /** Horizontal bar: conversion rate by outreach channel, fixed color per channel. */
  const CHANNEL_COLOR_VAR = { system: '--series-1', email: '--series-2', sms: '--series-3', call: '--series-7', human: '--series-5' };
  function buildChannelChart(container, channels) {
    container.innerHTML = '';
    const width = 560, rowH = 34, gap = 14, left = 118, right = 60;
    const height = channels.length * (rowH + gap) - gap + 6;
    const svg = el('svg', { class: 'chart-svg', viewBox: `0 0 ${width} ${height}`, role: 'img', 'aria-label': 'Conversion rate by outreach channel' }, container);
    const plotW = width - left - right;

    channels.forEach((c, i) => {
      const y = i * (rowH + gap);
      const w = Math.max(4, (c.rate / 100) * plotW);
      const color = cssVar(CHANNEL_COLOR_VAR[c.key] || '--brand') || '#1baf7a';
      el('text', { x: 0, y: y + rowH / 2 + 4, class: 'value-label' }, svg).textContent = c.label;
      const track = el('rect', { x: left, y, width: plotW, height: rowH, rx: 4, fill: cssVar('--surface-2') }, svg);
      const rect = el('rect', { x: left, y, width: w, height: rowH, rx: 4, fill: color }, svg);
      rect.style.cursor = 'pointer'; track.style.cursor = 'pointer';
      const tip = (e) => showTip(e, `<div class="t-title">${c.label}</div>${c.successes} of ${c.attempts} attempts converted · ${c.rate.toFixed(1)}%`);
      rect.addEventListener('mousemove', tip); track.addEventListener('mousemove', tip);
      rect.addEventListener('mouseleave', hideTip); track.addEventListener('mouseleave', hideTip);
      el('text', { x: left + plotW + 8, y: y + rowH / 2 + 4, fill: cssVar('--ink-2'), 'font-weight': 600 }, svg).textContent = c.rate.toFixed(0) + '%';
    });
  }

  /** Calendar heatmap: ₹ recovered per day per category, one hue, light→dark. */
  function buildHeatmap(container, rows, horizonDays) {
    container.innerHTML = '';
    const cell = 22, cellGap = 3, left = 110, top = 22, right = 10;
    const width = left + (horizonDays + 1) * (cell + cellGap) + right;
    const height = top + rows.length * (cell + cellGap) + 10;
    const svg = el('svg', { class: 'chart-svg', viewBox: `0 0 ${width} ${height}`, role: 'img', 'aria-label': 'Revenue recovered by day and category' }, container);
    const brand = cssVar('--brand') || '#1baf7a';
    const surface = cssVar('--surface-2') || '#f1f3f1';
    const max = Math.max(1, ...rows.flatMap((r) => r.cells.map((c) => c.value)));

    for (let d = 0; d <= horizonDays; d += 3) {
      el('text', { x: left + d * (cell + cellGap) + cell / 2, y: top - 8, 'text-anchor': 'middle', fill: cssVar('--ink-muted') }, svg).textContent = 'D' + d;
    }
    rows.forEach((row, ri) => {
      const y = top + ri * (cell + cellGap);
      el('text', { x: 0, y: y + cell / 2 + 4, fill: cssVar('--ink-2'), 'font-weight': 600 }, svg).textContent = row.label;
      row.cells.forEach((c) => {
        const x = left + c.day * (cell + cellGap);
        const t = c.value / max; // 0..1 intensity
        const fill = t <= 0.02 ? surface : mix(brand, surface, 1 - Math.max(0.12, t));
        const rect = el('rect', { x, y, width: cell, height: cell, rx: 5, fill }, svg);
        rect.style.cursor = 'pointer';
        rect.addEventListener('mousemove', (e) => showTip(e, `<div class="t-title">${row.label} · Day ${c.day}</div>${c.value > 0 ? fmtINR(c.value) + ' recovered' : 'Nothing recovered'}`));
        rect.addEventListener('mouseleave', hideTip);
      });
    });
  }

  global.ReclaimCharts = { buildStackedBarChart, buildFunnelChart, buildAreaChart, buildChannelChart, buildHeatmap, fmtINR };
})(typeof window !== 'undefined' ? window : globalThis);
