/**
 * ui.js — renders state to the DOM: KPI tiles, charts, the live audit
 * terminal, the sortable/filterable event table and its detail drawer.
 * No framework — the batch is small enough (100-300 rows) that direct DOM
 * writes stay fast and the code stays readable end to end.
 */
(function (global) {
  'use strict';
  const { fmtINR } = global.ReclaimCharts;
  const CATEGORY_META = global.ReclaimData.CATEGORY_META;

  const STATUS_LABEL = {
    new: 'Queued', in_progress: 'In progress', recovered: 'Recovered', lost: 'Lost',
    opted_out: 'Opted out', stopped_max_attempts: 'Attempts capped', escalated_human: 'With human agent',
  };
  const ACTION_TYPE_DOT = { action: 'dot-action', recovered: 'dot-recovered', stop: 'dot-stop', escalate: 'dot-escalate', defer: 'dot-defer' };

  const state = {
    events: [], timeline: [], baseline: null, openRowId: null,
    sort: { key: 'score', dir: 'desc' },
    filter: { category: 'all', search: '' },
    running: false,
  };

  function qs(sel, root) { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.from((root || document).querySelectorAll(sel)); }

  function animateNumber(elm, to, opts) {
    opts = opts || {};
    const from = 0, dur = opts.duration || 900, fmt = opts.format || ((n) => Math.round(n).toLocaleString('en-IN'));
    const start = performance.now();
    function tick(now) {
      const t = Math.min(1, (now - start) / dur);
      const eased = 1 - Math.pow(1 - t, 3);
      elm.textContent = fmt(from + (to - from) * eased);
      if (t < 1) requestAnimationFrame(tick); else elm.textContent = fmt(to);
    }
    requestAnimationFrame(tick);
  }

  // ---------------------------------------------------------------- KPIs --
  function computeKpis(events) {
    const atRisk = events.reduce((s, e) => s + e.amount, 0);
    const recoveredEvents = events.filter((e) => e.status === 'recovered');
    const recovered = recoveredEvents.reduce((s, e) => s + e.recoveredAmount, 0);
    const rate = atRisk ? (recovered / atRisk) * 100 : 0;
    const escalated = events.filter((e) => e.status === 'escalated_human').length;
    const stopped = events.filter((e) => ['opted_out', 'stopped_max_attempts', 'lost'].includes(e.status)).length;
    const avgDays = recoveredEvents.length
      ? recoveredEvents.reduce((s, e) => s + e.recoveredOnDay, 0) / recoveredEvents.length
      : 0;
    return { atRisk, recovered, rate, escalated, stopped, avgDays, n: events.length, recoveredCount: recoveredEvents.length };
  }

  function renderKpis(k) {
    animateNumber(qs('#kpi-atrisk'), k.atRisk, { format: (n) => fmtINR(n) });
    qs('#kpi-atrisk-sub').textContent = `across ${k.n} events`;
    animateNumber(qs('#kpi-recovered'), k.recovered, { format: (n) => fmtINR(n) });
    qs('#kpi-recovered-sub').textContent = `${k.recoveredCount} of ${k.n} events closed won`;
    animateNumber(qs('#kpi-rate'), k.rate, { format: (n) => n.toFixed(1) + '%' });
    qs('#kpi-rate-sub').textContent = k.avgDays ? `avg ${k.avgDays.toFixed(1)}d to recover` : 'no recoveries yet';
    animateNumber(qs('#kpi-escalated'), k.escalated, { format: (n) => Math.round(n).toString() });
    qs('#kpi-escalated-sub').textContent = 'handed to a human, not chased forever';
    animateNumber(qs('#kpi-stopped'), k.stopped, { format: (n) => Math.round(n).toString() });
    qs('#kpi-stopped-sub').textContent = 'closed by a guardrail, not silence';
  }

  // -------------------------------------------------------------- charts --
  function cssVarValue(v) {
    if (!v.startsWith('var(')) return v;
    const name = v.slice(4, -1);
    return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  }

  function renderCharts(events) {
    const cats = ['failed_payment', 'abandoned_checkout', 'overdue_invoice'];
    const resolved = [
      { key: 'recovered', label: 'Recovered', color: cssVarValue('var(--status-good)') },
      { key: 'active', label: 'Active / queued', color: cssVarValue('var(--status-warning)') },
      { key: 'human', label: 'With human agent', color: cssVarValue('var(--series-7)') },
      { key: 'closed', label: 'Lost / stopped', color: cssVarValue('var(--ink-muted)') },
    ];

    const rows = cats.map((c) => {
      const evs = events.filter((e) => e.category === c);
      const counts = { recovered: 0, active: 0, human: 0, closed: 0 };
      const amounts = { recovered: 0, active: 0, human: 0, closed: 0 };
      evs.forEach((e) => {
        let bucket;
        if (e.status === 'recovered') bucket = 'recovered';
        else if (e.status === 'escalated_human') bucket = 'human';
        else if (e.status === 'new' || e.status === 'in_progress') bucket = 'active';
        else bucket = 'closed';
        counts[bucket]++; amounts[bucket] += e.amount;
      });
      return { label: CATEGORY_META[c].label, total: evs.length, counts, amounts };
    });
    global.ReclaimCharts.buildStackedBarChart(qs('#chart-outcome'), rows,
      resolved.map((s) => ({ key: s.key, label: s.label, color: s.color })));

    // stage n = events that received at least n contact attempts
    const attemptsAtLeast = (n) => events.filter((e) => e.contactAttempts >= n).length;
    const funnel = [
      { label: 'First touch', count: attemptsAtLeast(1) },
      { label: 'Second touch', count: attemptsAtLeast(2) },
      { label: 'Third touch', count: attemptsAtLeast(3) },
      { label: 'Fourth touch', count: attemptsAtLeast(4) },
    ].filter((s) => s.count > 0 || true);
    global.ReclaimCharts.buildFunnelChart(qs('#chart-funnel'), funnel);

    const horizon = global.ReclaimEngine.HORIZON_DAYS;
    let running = 0;
    const byDay = new Array(horizon + 1).fill(0);
    events.forEach((e) => { if (e.status === 'recovered') byDay[Math.min(horizon, e.recoveredOnDay)] += e.recoveredAmount; });
    const points = byDay.map((v, day) => { running += v; return { day, value: running }; });
    global.ReclaimCharts.buildAreaChart(qs('#chart-area'), points);
  }

  // -------------------------------------------------------- impact strip --
  function renderImpact(k, baseline) {
    if (!baseline) return;
    const baseRate = baseline.atRisk ? (baseline.recovered / baseline.atRisk) * 100 : 0;
    animateNumber(qs('#impact-baseline'), baseline.recovered, { format: (n) => fmtINR(n) });
    qs('#impact-baseline-sub').textContent = `${baseRate.toFixed(1)}% · one generic reminder, sent to everyone alike`;
    animateNumber(qs('#impact-agent'), k.recovered, { format: (n) => fmtINR(n) });
    qs('#impact-agent-sub').textContent = `${k.rate.toFixed(1)}% · scored, staged, channel-matched`;
    const mult = baseline.recovered > 0 ? k.recovered / baseline.recovered : (k.recovered > 0 ? 99 : 1);
    qs('#impact-multiplier').textContent = (mult >= 9.9 ? '10x+' : mult.toFixed(1) + 'x');
    const extra = Math.max(0, k.recovered - baseline.recovered);
    qs('#impact-extra').textContent = `+${fmtINR(extra)} recovered on this batch that a single generic reminder would have left on the table`;
  }

  // ---------------------------------------------------- channels + heatmap --
  function computeChannelStats(events) {
    const byChannel = {};
    events.forEach((e) => e.auditLog.forEach((l) => {
      if (l.type !== 'action' || !l.channel) return;
      const c = (byChannel[l.channel] = byChannel[l.channel] || { attempts: 0, successes: 0 });
      c.attempts++; if (l.success) c.successes++;
    }));
    const LABEL = { system: 'Automated retry', email: 'Email', sms: 'SMS', call: 'Priority call' };
    return Object.keys(LABEL).filter((k) => byChannel[k]).map((k) => ({
      key: k, label: LABEL[k], attempts: byChannel[k].attempts, successes: byChannel[k].successes,
      rate: byChannel[k].attempts ? (byChannel[k].successes / byChannel[k].attempts) * 100 : 0,
    })).sort((a, b) => b.rate - a.rate);
  }

  function computeHeatmapRows(events, horizon) {
    return Object.keys(CATEGORY_META).map((cat) => {
      const cells = Array.from({ length: horizon + 1 }, (_, day) => ({ day, value: 0 }));
      events.filter((e) => e.category === cat && e.status === 'recovered').forEach((e) => {
        cells[Math.min(horizon, e.recoveredOnDay)].value += e.recoveredAmount;
      });
      return { label: CATEGORY_META[cat].short, cells };
    });
  }

  function renderChannelsAndHeatmap(events) {
    const channels = computeChannelStats(events);
    global.ReclaimCharts.buildChannelChart(qs('#chart-channels'), channels);
    const horizon = global.ReclaimEngine.HORIZON_DAYS;
    global.ReclaimCharts.buildHeatmap(qs('#chart-heatmap'), computeHeatmapRows(events, horizon), horizon);
    return channels;
  }

  // ------------------------------------------------------------ leaderboard --
  function renderLeaderboard(events) {
    const top = [...events].sort((a, b) => b.amount - a.amount).slice(0, 8);
    qs('#leaderboard').innerHTML = top.map((e) => `
      <div class="lb-row" data-id="${e.id}">
        <div class="cust"><span>${e.customerName}</span>${e.company ? `<span class="company">${e.company}</span>` : ''}</div>
        <span class="lb-cat">${CATEGORY_META[e.category].short}</span>
        <span class="num lb-amount">${fmtINR(e.amount)}</span>
        <div class="score-bar"><div class="score-track"><i style="width:${e.score}%"></i></div><span class="num">${e.score}</span></div>
        ${statusPill(e.status)}
      </div>`).join('');
    qsa('#leaderboard .lb-row').forEach((row) => row.addEventListener('click', () => jumpToEvent(row.dataset.id)));
  }

  function jumpToEvent(id) {
    setTab('portfolio');
    state.openRowId = id;
    state.filter.category = 'all'; state.filter.search = '';
    qsa('.chip[data-cat]').forEach((c) => c.setAttribute('aria-pressed', c.dataset.cat === 'all' ? 'true' : 'false'));
    if (qs('#search')) qs('#search').value = '';
    renderTable();
    requestAnimationFrame(() => { const r = qs(`tr[data-id="${id}"]`); if (r) r.scrollIntoView({ behavior: 'smooth', block: 'center' }); });
  }

  // -------------------------------------------------------------- insights --
  function renderInsights(events, k, baseline, channels) {
    const bullets = [];
    const cats = Object.keys(CATEGORY_META);
    const byCat = cats.map((cat) => {
      const evs = events.filter((e) => e.category === cat);
      const rec = evs.filter((e) => e.status === 'recovered');
      const atRisk = evs.reduce((s, e) => s + e.amount, 0);
      const recovered = rec.reduce((s, e) => s + e.recoveredAmount, 0);
      return { cat, label: CATEGORY_META[cat].label, rate: atRisk ? (recovered / atRisk) * 100 : 0, n: evs.length };
    });
    const best = byCat.reduce((a, b) => (b.rate > a.rate ? b : a));
    const worst = byCat.reduce((a, b) => (b.rate < a.rate ? b : a));
    bullets.push(`<b>${best.label}</b> recovered best this batch at <b>${best.rate.toFixed(0)}%</b> — the escalation plan for this category is working as designed.`);
    if (worst.cat !== best.cat) {
      bullets.push(`<b>${worst.label}</b> lagged at <b>${worst.rate.toFixed(0)}%</b>. Worth a look before scaling this batch size up.`);
    }
    if (channels.length) {
      const topCh = channels[0];
      bullets.push(`<b>${topCh.label}</b> converted best of any channel this run, at <b>${topCh.rate.toFixed(0)}%</b> across ${topCh.attempts} attempts.`);
    }
    const deferred = events.reduce((s, e) => s + e.auditLog.filter((l) => l.type === 'defer').length, 0);
    if (deferred > 0) bullets.push(`<b>${deferred}</b> scheduled sends fell inside quiet hours and were deferred rather than fired anyway — zero compliance exceptions.`);
    if (baseline) {
      const mult = baseline.recovered > 0 ? k.recovered / baseline.recovered : k.recovered > 0 ? 99 : 1;
      bullets.push(`This run recovered <b>${(mult >= 9.9 ? '10x+' : mult.toFixed(1) + 'x')}</b> what a single flat, unscored reminder would have — the scoring and staging is doing real work, not just adding noise.`);
    }
    bullets.push(`<b>${k.escalated}</b> hard cases went to a human instead of being auto-retried into the ground; <b>${k.stopped}</b> more were closed cleanly by a guardrail rather than left hanging.`);
    qs('#insights-list').innerHTML = bullets.map((b) => `<li>${b}</li>`).join('');
  }

  // --------------------------------------------------------------- table --
  function statusPill(status) {
    return `<span class="pill st-${status}"><i></i>${STATUS_LABEL[status] || status}</span>`;
  }

  function passesFilter(e) {
    const f = state.filter;
    if (f.category !== 'all' && e.category !== f.category) return false;
    if (f.search) {
      const q = f.search.toLowerCase();
      const hay = `${e.customerName} ${e.company || ''} ${e.id}`.toLowerCase();
      if (!hay.includes(q)) return false;
    }
    return true;
  }

  function sortEvents(list) {
    const { key, dir } = state.sort;
    const mult = dir === 'asc' ? 1 : -1;
    return [...list].sort((a, b) => {
      let av = a[key], bv = b[key];
      if (key === 'customer') { av = a.customerName; bv = b.customerName; }
      if (typeof av === 'string') return av.localeCompare(bv) * mult;
      return ((av || 0) - (bv || 0)) * mult;
    });
  }

  function renderTable() {
    const tbody = qs('#events-tbody');
    const list = sortEvents(state.events.filter(passesFilter));
    qs('#table-count').textContent = `${list.length} of ${state.events.length} events`;

    tbody.innerHTML = '';
    if (!list.length) {
      tbody.innerHTML = `<tr><td colspan="7" style="padding:26px;text-align:center;color:var(--ink-muted)">No events match this filter.</td></tr>`;
      return;
    }
    for (const e of list) {
      const tr = document.createElement('tr');
      tr.dataset.id = e.id;
      if (state.openRowId === e.id) tr.classList.add('is-open');
      tr.innerHTML = `
        <td><div class="cust"><span>${e.customerName}</span>${e.company ? `<span class="company">${e.company}</span>` : ''}</div></td>
        <td>${CATEGORY_META[e.category].short}</td>
        <td class="num-col num">${fmtINR(e.amount)}</td>
        <td><div class="score-bar"><div class="score-track"><i style="width:${e.score}%"></i></div><span class="num">${e.score}</span></div></td>
        <td>${statusPill(e.status)}</td>
        <td class="num-col num">${e.daysSinceEvent}d</td>
        <td>${e.contactAttempts}</td>`;
      tr.addEventListener('click', () => toggleRow(e.id));
      tbody.appendChild(tr);
      if (state.openRowId === e.id) tbody.appendChild(buildDrawer(e));
    }
  }

  function buildDrawer(e) {
    const tr = document.createElement('tr');
    tr.className = 'drawer-row';
    const td = document.createElement('td');
    td.colSpan = 7;
    const maxAbs = Math.max(1, ...e.scoreFactors.map((f) => Math.abs(f.delta)));
    const factorsHtml = e.scoreFactors.map((f) => {
      const pct = (Math.abs(f.delta) / maxAbs) * 45;
      const cls = f.delta >= 0 ? 'pos' : 'neg';
      const style = f.delta >= 0 ? `left:50%;width:${pct}%` : `right:50%;width:${pct}%`;
      return `<div class="factor-row"><span class="factor-label">${f.label}</span>
        <span class="factor-bar-track"><span class="factor-bar-fill ${cls}" style="${style}"></span></span>
        <span class="factor-delta num">${f.delta > 0 ? '+' : ''}${f.delta}</span></div>`;
    }).join('');
    const logHtml = e.auditLog.map((l) => `
      <div class="log-row"><span class="lr-day mono">${l.ts}</span><span class="lr-dot ${ACTION_TYPE_DOT[l.type] || 'dot-action'}"></span><span class="lr-msg">${l.message}</span></div>
    `).join('');
    td.innerHTML = `<div class="drawer">
      <div>
        <h4>Why this score — ${e.score}/100 (${e.policy.band} band)</h4>
        ${factorsHtml}
        <p style="margin-top:10px;font-size:12px;color:var(--ink-muted)">Recommended: <b style="color:var(--ink-2)">${e.policy.channel.replace(/_/g, ' ')}</b>${e.policy.offer !== 'none' ? `, offer <b style="color:var(--ink-2)">${e.policy.offer.replace(/_/g, ' ')}</b>` : ''} — urgency ${e.policy.urgency}.</p>
      </div>
      <div>
        <h4>Audit trail for ${e.id}</h4>
        <div class="mini-log">${logHtml || '<p style="color:var(--ink-muted);font-size:12px">No actions taken.</p>'}</div>
      </div>
    </div>`;
    tr.appendChild(td);
    return tr;
  }

  function toggleRow(id) {
    state.openRowId = state.openRowId === id ? null : id;
    renderTable();
  }

  // ------------------------------------------------------------- terminal --
  function streamLog(timeline) {
    const term = qs('#terminal');
    term.innerHTML = '';
    if (!timeline.length) return;
    const totalMs = 2400;
    const perTick = Math.max(1, Math.ceil(timeline.length / (totalMs / 24)));
    let i = 0;
    function tick() {
      const frag = document.createDocumentFragment();
      for (let n = 0; n < perTick && i < timeline.length; n++, i++) {
        const l = timeline[i];
        const row = document.createElement('div');
        row.className = 'log-row';
        row.innerHTML = `<span class="lr-day mono">${l.ts}</span><span class="lr-id mono">${l.eventId}</span><span class="lr-dot ${ACTION_TYPE_DOT[l.type] || 'dot-action'}"></span><span class="lr-msg"><span class="who">${l.customer} · ${fmtINR(l.amount)} —</span> ${l.message}</span>`;
        frag.appendChild(row);
      }
      term.appendChild(frag);
      term.scrollTop = term.scrollHeight;
      if (i < timeline.length) requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  }

  // ------------------------------------------------------------ playbook --
  function renderPlaybook() {
    const el = qs('#playbook');
    const plans = global.ReclaimEngine.CATEGORY_PLANS;
    const colors = { failed_payment: 'var(--series-1)', abandoned_checkout: 'var(--series-3)', overdue_invoice: 'var(--series-4)' };
    el.innerHTML = Object.keys(plans).map((cat) => `
      <div class="playbook-col">
        <h3><span class="swatch" style="background:${colors[cat]}"></span>${CATEGORY_META[cat].label}</h3>
        ${plans[cat].map((s) => `<div class="pb-step"><span class="pb-day mono">Day ${s.dayOffset}</span><span class="pb-action"><b>${global.ReclaimEngine.ACTION_META[s.action].label}</b>${s.lowBandAction ? ` <span style="color:var(--ink-muted)">(or ${global.ReclaimEngine.ACTION_META[s.lowBandAction].label.toLowerCase()} for low-recoverability cases)</span>` : ''}</span></div>`).join('')}
      </div>`).join('');
  }

  // ------------------------------------------------------------------ tabs --
  function setTab(name) {
    qsa('.tab-btn').forEach((b) => b.setAttribute('aria-selected', b.dataset.tab === name ? 'true' : 'false'));
    qsa('.tab-panel').forEach((p) => { p.hidden = p.dataset.tabPanel !== name; });
  }
  function wireTabs() {
    qsa('.tab-btn').forEach((b) => b.addEventListener('click', () => setTab(b.dataset.tab)));
  }

  // -------------------------------------------------------- config panel --
  function wireConfigPanel(onApply) {
    const readouts = {
      'cfg-maxattempts': (v) => (v > 0 ? `+${v} touches` : v < 0 ? `${v} touches` : 'default'),
      'cfg-timeout': (v) => (v > 0 ? `+${v}d window` : v < 0 ? `${v}d window` : 'default'),
      'cfg-discount': (v) => `+${v}pt on offers`,
    };
    Object.keys(readouts).forEach((id) => {
      const input = qs('#' + id), out = qs('#' + id + '-out');
      if (!input || !out) return;
      const update = () => { out.textContent = readouts[id](parseInt(input.value, 10)); };
      input.addEventListener('input', update);
      update();
    });
    qs('#btn-apply-config').addEventListener('click', onApply);
    qs('#btn-reset-config').addEventListener('click', () => {
      qs('#cfg-maxattempts').value = 0; qs('#cfg-timeout').value = 0; qs('#cfg-discount').value = 0;
      qs('#cfg-quiethours').checked = true;
      Object.keys(readouts).forEach((id) => qs('#' + id).dispatchEvent(new Event('input')));
      onApply();
    });
  }
  function readConfig() {
    return {
      maxAttemptsDelta: parseInt(qs('#cfg-maxattempts').value, 10) || 0,
      timeoutDaysDelta: parseInt(qs('#cfg-timeout').value, 10) || 0,
      discountBoost: parseInt(qs('#cfg-discount').value, 10) || 0,
      quietHoursEnabled: qs('#cfg-quiethours').checked,
    };
  }

  // ---------------------------------------------------------------- glue --
  function wireControls(onRun) {
    qs('#btn-run').addEventListener('click', onRun);
    qsa('.chip[data-cat]').forEach((chip) => {
      chip.addEventListener('click', () => {
        qsa('.chip[data-cat]').forEach((c) => c.setAttribute('aria-pressed', 'false'));
        chip.setAttribute('aria-pressed', 'true');
        state.filter.category = chip.dataset.cat;
        renderTable();
      });
    });
    qsa('th[data-key]').forEach((th) => {
      th.addEventListener('click', () => {
        const key = th.dataset.key;
        state.sort.dir = state.sort.key === key && state.sort.dir === 'desc' ? 'asc' : 'desc';
        state.sort.key = key;
        renderTable();
      });
    });
    qs('#search').addEventListener('input', (e) => { state.filter.search = e.target.value; renderTable(); });
    wireTabs();
    wireConfigPanel(onRun);
  }

  function render(events, timeline, baseline) {
    state.events = events; state.timeline = timeline; state.openRowId = null; state.baseline = baseline;
    const k = computeKpis(events);
    renderKpis(k);
    renderImpact(k, baseline);
    renderCharts(events);
    const channels = renderChannelsAndHeatmap(events);
    renderLeaderboard(events);
    renderInsights(events, k, baseline, channels);
    renderTable();
    streamLog(timeline);
  }

  global.ReclaimUI = { render, wireControls, renderPlaybook, readConfig, state };
})(typeof window !== 'undefined' ? window : globalThis);
