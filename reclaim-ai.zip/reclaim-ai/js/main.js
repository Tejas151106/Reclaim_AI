/**
 * main.js — bootstraps the demo: generate a batch, run the simulation,
 * render, and wire the controls so a judge (or you, in the pitch video)
 * can re-run with a different seed/size and watch the agent work again.
 */
(function () {
  'use strict';

  function currentSeed() { return parseInt(document.getElementById('seed').value, 10) || 42; }
  function currentSize() { return Math.max(20, Math.min(400, parseInt(document.getElementById('size').value, 10) || 160)); }

  function runBatch() {
    const btn = document.getElementById('btn-run');
    btn.dataset.running = 'true';
    btn.disabled = true;
    // yield a frame so the spinner shows even though the sim itself is fast
    requestAnimationFrame(() => {
      setTimeout(() => {
        const seed = currentSeed(), size = currentSize();
        const config = window.ReclaimUI.readConfig();
        const events = window.ReclaimData.generateBatch(seed, size);
        const { events: scored, timeline } = window.ReclaimEngine.runSimulation(events, seed, config);
        const baseline = window.ReclaimEngine.runBaseline(seed, size);
        window.ReclaimUI.render(scored, timeline, baseline);
        document.getElementById('run-meta').textContent =
          `Seed ${seed} · ${size} synthetic events · ${window.ReclaimEngine.HORIZON_DAYS}-day recovery window`;
        btn.dataset.running = 'false';
        btn.disabled = false;
      }, 50);
    });
  }

  document.addEventListener('DOMContentLoaded', () => {
    window.ReclaimUI.wireControls(runBatch);
    window.ReclaimUI.renderPlaybook();
    runBatch();
  });
})();
