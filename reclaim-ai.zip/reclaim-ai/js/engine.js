/**
 * engine.js — the recovery workflow: escalation, stopping rules, audit trail
 * ----------------------------------------------------------------------------
 * This is the part of the agent that *acts*. It steps a synthetic batch
 * forward day by day across a bounded recovery window and, for every event,
 * either takes the next scripted step in its category's escalation plan or
 * halts it under one of four explicit stopping rules. Every action — taken
 * or withheld — is written to an immutable audit entry, because "AI took an
 * action on someone's money" is exactly the kind of decision a compliance
 * reviewer needs to reconstruct after the fact.
 *
 * Escalation plans are intentionally a flat, readable table (CATEGORY_PLANS)
 * rather than a learned policy — see scoring.js for where the one probabilistic
 * component (recoverability) is isolated and swappable.
 */
(function (global) {
  'use strict';

  const ACTION_META = {
    auto_retry:         { label: 'Automated payment retry', channel: 'system', mult: null },
    email_reminder:      { label: 'Reminder email sent',     channel: 'email',  mult: 0.35 },
    sms_nudge:           { label: 'SMS nudge sent',          channel: 'sms',    mult: 0.42 },
    email_offer:         { label: 'Offer email sent',        channel: 'email',  mult: 0.50 },
    payment_plan_offer:  { label: 'Payment-plan offer sent', channel: 'email',  mult: 0.55 },
    priority_call:       { label: 'Priority call queued',    channel: 'call',   mult: 0.60 },
    human_escalation:    { label: 'Escalated to collections agent', channel: 'human', mult: 0.60 },
    final_notice:        { label: 'Final notice sent',       channel: 'email',  mult: 0.20 },
  };

  // dayOffset is measured from the start of the simulated recovery window.
  const CATEGORY_PLANS = {
    failed_payment: [
      { stage: 0, dayOffset: 0, action: 'auto_retry' },
      { stage: 1, dayOffset: 2, action: 'sms_nudge' },
      { stage: 2, dayOffset: 5, action: 'email_offer', lowBandAction: 'priority_call' },
      { stage: 3, dayOffset: 9, action: 'final_notice' },
    ],
    abandoned_checkout: [
      { stage: 0, dayOffset: 0, action: 'email_reminder' },
      { stage: 1, dayOffset: 1, action: 'sms_nudge' },
      { stage: 2, dayOffset: 3, action: 'email_offer' },
      { stage: 3, dayOffset: 7, action: 'final_notice' },
    ],
    overdue_invoice: [
      { stage: 0, dayOffset: 0, action: 'email_reminder' },
      { stage: 1, dayOffset: 3, action: 'sms_nudge' },
      { stage: 2, dayOffset: 7, action: 'payment_plan_offer', lowBandAction: 'payment_plan_offer' },
      { stage: 3, dayOffset: 10, action: 'human_escalation' },
    ],
  };

  const CATEGORY_RULES = {
    failed_payment:      { maxAttempts: 3, timeoutDays: 14 },
    abandoned_checkout:  { maxAttempts: 3, timeoutDays: 10 },
    overdue_invoice:     { maxAttempts: 4, timeoutDays: 21 },
  };

  const HORIZON_DAYS = 21; // full simulated recovery window

  const DEFAULT_CONFIG = {
    maxAttemptsDelta: 0,   // added to each category's base contact/retry cap
    timeoutDaysDelta: 0,   // added to each category's recovery-window timeout
    discountBoost: 0,      // 0-15: percentage points added to offer-step conversion
    quietHoursEnabled: true,
  };

  function fmtDay(day) { return `Day ${day}`; }

  /**
   * Run the full recovery simulation over a batch of scored events.
   * Mutates each event with its final status/log and returns a flat,
   * chronologically-ordered timeline for UI playback.
   *
   * @param {object} [config] — live guardrail tuning, see DEFAULT_CONFIG. This
   *   is what the "Agent configuration" panel drives: the same bounded knobs a
   *   real operator would be allowed to turn, nothing that removes a guardrail
   *   outright.
   */
  function runSimulation(events, seed, config) {
    const cfg = Object.assign({}, DEFAULT_CONFIG, config);
    const rng = global.ReclaimData.makeRng((seed ^ 0x9e3779b9) >>> 0);
    const timeline = [];
    let tick = 0;

    function log(ev, day, type, message, extra) {
      const entry = {
        tick: tick++, day, ts: fmtDay(day), eventId: ev.id, type, message,
        category: ev.category, customer: ev.customerName, amount: ev.amount,
        ...extra,
      };
      ev.auditLog.push(entry);
      timeline.push(entry);
      return entry;
    }

    for (const ev of events) {
      const { score, factors } = global.ReclaimScoring.scoreEvent(ev);
      ev.score = score;
      ev.scoreFactors = factors;
      ev.policy = global.ReclaimScoring.decidePolicy(ev, score);

      // --- stopping rule 1: do-not-contact is checked once, up front ---
      if (ev.doNotContact) {
        ev.status = 'opted_out';
        log(ev, 0, 'stop', 'Suppressed — customer is flagged do-not-contact. No outreach generated.', { rule: 'dnc' });
        continue;
      }

      const plan = CATEGORY_PLANS[ev.category];
      const baseRules = CATEGORY_RULES[ev.category];
      const rules = {
        maxAttempts: Math.max(1, baseRules.maxAttempts + cfg.maxAttemptsDelta),
        timeoutDays: Math.max(3, baseRules.timeoutDays + cfg.timeoutDaysDelta),
      };
      let resolved = false;
      let autoRetryCount = 0;

      for (const step of plan) {
        const day = step.dayOffset;
        if (day > rules.timeoutDays) break;

        // --- stopping rule 2: recovery window has expired ---
        if (day >= rules.timeoutDays) {
          // handled after loop as fallback; plans are built to stay inside window
        }

        // --- stopping rule 3: hard cap on automated card retries ---
        let action = (ev.policy.band === 'low' && step.lowBandAction) ? step.lowBandAction : step.action;
        if (action === 'auto_retry') {
          if (!ev.failureTransient && autoRetryCount >= 1) action = 'sms_nudge'; // never hammer a hard decline
          if (autoRetryCount >= 2) action = 'sms_nudge';
          autoRetryCount++;
        }

        // --- stopping rule 4: contact-frequency cap ---
        if (ev.contactAttempts >= rules.maxAttempts) {
          ev.status = 'stopped_max_attempts';
          log(ev, day, 'stop', `Max contact attempts (${rules.maxAttempts}) reached — automated outreach halted, does not resume.`, { rule: 'max_attempts' });
          resolved = true;
          break;
        }

        // Simulated quiet-hours deferral (9pm–9am IST) — a small compliance
        // touch: roughly 1 in 7 scheduled sends would land in quiet hours,
        // so the agent visibly reschedules instead of firing anyway.
        let sendDay = day;
        if (cfg.quietHoursEnabled && rng.float() < 0.14) {
          sendDay = day + 1;
          log(ev, day, 'defer', 'Scheduled send fell inside quiet hours (9pm–9am IST) — deferred to next window.', { rule: 'quiet_hours' });
        }

        const meta = ACTION_META[action];
        ev.contactAttempts++;
        ev.escalationStage = step.stage;
        const isOfferStep = action === 'email_offer' || action === 'payment_plan_offer';
        let p = action === 'auto_retry'
          ? (ev.failureTransient ? score / 100 * 0.9 + 0.05 : score / 100 * 0.45)
          : (score / 100) * meta.mult;
        if (isOfferStep) p = Math.min(0.97, p + cfg.discountBoost / 100);

        const success = rng.float() < p;
        log(ev, sendDay, action === 'human_escalation' ? 'escalate' : 'action',
          `${meta.label}${action === 'human_escalation' ? '' : ' — '}${action === 'human_escalation' ? '' : (success ? 'resolved' : 'no response yet')}`,
          { channel: meta.channel, stage: step.stage, success });

        if (success) {
          ev.status = 'recovered';
          ev.recoveredAmount = ev.amount;
          ev.recoveredOnDay = sendDay;
          log(ev, sendDay, 'recovered', `Payment recovered in full (₹${ev.amount.toLocaleString('en-IN')}). All further outreach cancelled.`, { rule: 'recovered_stop' });
          resolved = true;
          break;
        }

        if (action === 'human_escalation') {
          ev.status = 'escalated_human';
          log(ev, sendDay, 'stop', 'Hard case — handed off to a human collections agent. Agent authority ends here by design.', { rule: 'human_handoff' });
          resolved = true;
          break;
        }
      }

      if (!resolved) {
        ev.status = 'lost';
        log(ev, rules.timeoutDays, 'stop', `Recovery window expired (${rules.timeoutDays}d) with no response — closed, referred to standard collections.`, { rule: 'timeout' });
      }
    }

    timeline.sort((a, b) => a.day - b.day || a.tick - b.tick);
    return { events, timeline };
  }

  /**
   * The counterfactual: what a business gets with no agent at all — a single
   * generic reminder, sent to everyone alike, with no scoring, no channel
   * selection, no offers, no escalation. This exists purely to give the
   * "recovered ₹X" number a baseline to be measured against, since a bare
   * total means nothing without one. Runs on an independently-seeded batch
   * of the *same* size/shape so the comparison is apples-to-apples in
   * aggregate, without sharing mutable state with the agent run.
   */
  function runBaseline(seed, size, flatRate) {
    const events = global.ReclaimData.generateBatch(seed, size);
    const rng = global.ReclaimData.makeRng((seed ^ 0x51ed270b) >>> 0);
    const rate = typeof flatRate === 'number' ? flatRate : 0.12;
    let atRisk = 0, recovered = 0, contacted = 0;
    for (const ev of events) {
      atRisk += ev.amount;
      if (ev.doNotContact) continue; // even a manual process should honor this
      contacted++;
      if (rng.float() < rate) recovered += ev.amount;
    }
    return { atRisk, recovered, contacted, n: events.length, rate };
  }

  global.ReclaimEngine = { runSimulation, runBaseline, CATEGORY_PLANS, CATEGORY_RULES, ACTION_META, HORIZON_DAYS, DEFAULT_CONFIG };
})(typeof window !== 'undefined' ? window : globalThis);
