# ReclaimAI — an AI Revenue Recovery agent

Built for the **AI Revenue Recovery** track of the Razorpay AI Buildathon 2026.

> Build agents that identify revenue loss and execute recovery workflows across payment
> failures, checkout abandonment, and overdue receivables — with measured money
> recovered across a batch, compliant escalation, stopping rules, and an audit trail.

ReclaimAI is a client-side agent + dashboard that does exactly that against a
reproducible synthetic batch: it **scores** every failed payment, abandoned checkout
and overdue invoice for recoverability, runs each one through a **bounded, staged
recovery playbook**, and reports what actually got recovered — with every action the
agent took (or deliberately withheld) written to an audit trail you can inspect
per-event.

![Dashboard](docs/screenshot-dashboard.png)

## Why this exists

Most "AI for collections" pitches are a chatbot that emails people more. The actual
hard problem — the one this track is scoring on — is **restraint**: knowing which
cases are worth pursuing, running a playbook that reads as a serious business
process rather than spam, and being able to prove to a compliance reviewer exactly
why the agent did what it did. ReclaimAI is built around that constraint, not around
the chatbot.

## What it does

The app is organized into four tabs:

**Overview** — the headline run: KPI row, and an **"AI vs. manual" impact strip**
that runs the *same* synthetic batch through a second, deliberately dumb baseline
policy (one flat reminder, sent to everyone alike, no scoring) so the recovery
number has something to be measured against — plus the outcome-by-category chart,
escalation funnel, cumulative-recovery chart, and a live-streaming audit trail.

**Portfolio** — a "top at-risk accounts" leaderboard, and the full, sortable,
filterable event table. Click any row (here or in the leaderboard) to open a
detail drawer with that event's complete score breakdown and audit timeline.

**Playbook & Controls** — the fixed per-category escalation plans, the four
guardrail cards, and a live **agent configuration panel**: bounded sliders for the
contact/retry cap, the recovery-window length, offer strength, and a quiet-hours
toggle. Hit "Apply & re-run" and the whole batch re-simulates with the new
guardrail settings — a direct, visible demonstration that the agent is tunable
without any of its stopping rules being removable.

**Insights** — a plain-language executive summary computed live from the run's own
numbers (not canned text — change the seed and it rewrites itself), a
conversion-by-channel chart, and a day-by-category recovery heatmap.

Underneath, in order:

1. **Generates a synthetic batch** (seeded, reproducible) of 20–400 revenue-loss
   events across three categories: failed payments, abandoned checkouts, and overdue
   receivables — modeled on a mid-size Indian SaaS/D2C merchant (`js/data.js`).
2. **Scores every event 0–100** on recoverability using a transparent, fully
   decomposable weighted model — recency, failure-reason, customer tenure and
   payment history, category, amount (`js/scoring.js`). No black box: click any row
   in the table to see exactly which factors pushed the score up or down.
3. **Runs a staged recovery playbook** per category (auto-retry → SMS → offer →
   final notice / human escalation), simulating outcomes day-by-day over a bounded
   21-day window, with live-tunable guardrails (`js/engine.js`).
4. **Enforces four explicit stopping rules** so the agent never over-reaches:
   a contact/retry cap per case, do-not-contact suppression, simulated quiet-hours
   deferral, and a hard recovery-window timeout that hands unresolved cases to
   standard collections.
5. **Writes an immutable audit entry for every action** — taken or withheld — so the
   full timeline for any single event, or the whole batch, can be reconstructed.
6. **Reports the batch result against a baseline**: total at-risk revenue, ₹
   actually recovered vs. what a naive single-touch process would recover, recovery
   rate, channel-by-channel conversion, and how many cases were escalated to a
   human vs. closed by a guardrail.

## Track alignment

| Judging bar | Where it shows up |
|---|---|
| Measured money recovered across a batch | KPI row + cumulative-recovery chart + baseline comparison (Overview tab), computed live from the run |
| Payment failures, checkout abandonment, overdue receivables | All three categories are modeled with realistic, distinct dynamics |
| Compliant escalation | Category playbooks (`js/engine.js`), visualized in the "Recovery playbook" panel |
| Stopping rules | Four guardrails enforced in the engine and called out in the "Guardrails" panel |
| Audit trail | Per-event, per-action log (`auditLog`), streamed live and inspectable per row |

## Run it

No build step, no server-side code, no API keys.

```bash
git clone <this-repo>
cd reclaim-ai
python3 -m http.server 8000   # or: npx serve .
# open http://localhost:8000
```

Or just open `index.html` directly in a browser — everything runs client-side.
Change the **seed** or **batch size** in the top bar and hit **Run recovery batch**
to re-simulate.

## Architecture

See [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) for the scoring model, the
workflow state machine, the compliance design, and — importantly — exactly where a
production build would plug in a real Razorpay Payments/Invoices feed and a real
messaging provider in place of the synthetic data and simulated outcomes.

## Honest scope

This is a buildathon submission, not a production system, and it says so out loud
rather than pretending otherwise:

- **Data is synthetic.** No real payment data or PII was used or is required. The
  generator (`js/data.js`) is the single swap-in point for a real Razorpay
  Payments/Invoices poller.
- **Outcomes are simulated**, not real sends. The probability model in
  `js/engine.js` stands in for real channel conversion rates until there's a real
  messaging integration to measure against.
- **No LLM call is made from this page** — the artifact-hosted demo is sandboxed
  against outbound calls anyway. The scoring/decision layer is a transparent
  rule-based model on purpose (explainability was an explicit judging bar); see
  `docs/ARCHITECTURE.md` for where an LLM would slot in for message personalization
  without changing anything else.

## Tech

Vanilla HTML/CSS/JS, no framework, no build step, no dependencies beyond a Google
Fonts stylesheet (IBM Plex Sans/Mono). All charts are hand-built inline SVG.

## License

MIT — see [`LICENSE`](LICENSE).
